const tf = require("@tensorflow/tfjs");
const use = require("@tensorflow-models/universal-sentence-encoder")
const trainData = require("./postings.json");

const MODEL_NAME = "postings-model";
const N_CLASSES = 2;

async function normalize(encoder, postings) {
    const text = postings.map((p) => p.text.toLowerCase());
    const embeddings = await encoder.embed(text);
    return embeddings;
}

async function train() {
    const encoder = await use.load();
    try {
        const loadedModel = await tf.loadLayersModel(MODEL_NAME);
        console.log("Using existing model");
        return loadedModel;
    } catch (e) {
        console.log("Training new model");
    }

    const xTrain = await normalize(encoder, trainData);
    const yTrain = tf.tensor2d(
        trainData.map((p) => [p.fraudulent === "Real" ? 1 : 0])
    );

    const model = tf.sequential();

    model.add(
        tf.layers.dense({
            inputShape: [xTrain.shape[1]],
            activation: "softmax",
            units: N_CLASSES
        })
    );

    model.compile({
        loss: "categoricalCrossentropy",
        optimizer: tf.train.adam(0.001),
        metrics: ["accuracy"]
    });

    await model.fit(xTrain, yTrain, {
        batchSize: 32,
        validationSplit: 0.1,
        shuffle: true,
        epochs: 150
    })

    await model.save(MODEL_NAME);

    return model;
}

train();